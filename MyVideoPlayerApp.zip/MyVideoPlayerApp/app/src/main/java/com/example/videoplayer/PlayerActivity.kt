package com.example.videoplayer

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class PlayerActivity : AppCompatActivity() {
    private lateinit var videoView: VLCVideoLayout
    private lateinit var libVlc: LibVLC
    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        videoView = findViewById(R.id.videoView)

        val args = ArrayList<String>()
        args.add("--no-drop-late-frames")
        args.add("--no-skip-frames")
        libVlc = LibVLC(this, args)
        mediaPlayer = MediaPlayer(libVlc)

        val videoPath = intent.getStringExtra("videoPath")
        val media = Media(libVlc, Uri.parse(videoPath!!))
        mediaPlayer.attachViews(videoView, null, false, false)
        mediaPlayer.media = media
        mediaPlayer.play()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
        libVlc.release()
    }
}