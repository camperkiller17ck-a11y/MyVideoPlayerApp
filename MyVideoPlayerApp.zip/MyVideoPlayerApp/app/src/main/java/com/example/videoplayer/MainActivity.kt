package com.example.videoplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var videoAdapter: VideoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val videoList = getAllVideos()
        videoAdapter = VideoAdapter(videoList) { videoPath ->
            val intent = Intent(this, PlayerActivity::class.java)
            intent.putExtra("videoPath", videoPath)
            startActivity(intent)
        }
        recyclerView.adapter = videoAdapter
    }

    private fun getAllVideos(): List<String> {
        val videoList = mutableListOf<String>()
        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val cursor = contentResolver.query(uri, null, null, null, null)

        cursor?.use {
            val columnIndex = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            while (it.moveToNext()) {
                videoList.add(it.getString(columnIndex))
            }
        }
        return videoList
    }
}